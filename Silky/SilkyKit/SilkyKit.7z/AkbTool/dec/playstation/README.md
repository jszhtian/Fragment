I have no idea if this is Sony's format, or if it belongs to some third party
engine. If someone knows more details, please let me know so I can improve
namespaces.
