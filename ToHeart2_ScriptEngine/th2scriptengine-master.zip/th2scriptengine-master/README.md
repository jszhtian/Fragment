# th2scriptengine
My aquaplus-sources mod for ToHeart 2 XRATED

## How to build  
* With VS2010 only, VS2013 may be ok  

## Key code  
* search Main_Loop()  

## Ref  
* aquaplus-sources  
http://leaf.aquaplus.co.jp/product/xvid.html  
https://github.com/autch/aquaplus_gpl  
https://github.com/jeeb/aquaplus-sources  

* Test Data  
https://gitee.com/weimingtom/th2scriptengine_data  

## History  
* 2018-06-23: Migrate to github.    
* 2013-09-05: Last running.    
* 2011-06-19: Last mod.  
