#pragma once

extern int Cal2Disgit( TCHAR *cal);
