﻿#pragma once

#ifndef	TITLE_H_
#define TITLE_H_

extern int	InitBootFlag;
extern int	TaikenBan;
extern int	ShortCut;
extern int	TTL_System( void );

#endif	//TITLE_H_